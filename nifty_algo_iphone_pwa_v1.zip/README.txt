NIFTY ALGO PWA - Version 1.0

This is a front-end prototype only.
- No live NIFTY data connection
- No Angel One authentication/API connection
- No actual order placement
- Demo signal calculations only

To install on iPhone:
1. Host this folder on an HTTPS website (service workers require HTTPS).
2. Open the website in Safari on iPhone.
3. Tap Share -> Add to Home Screen -> Add.

Next development steps:
1. Confirm exact candle rule and whether 9:17 entry uses the 9:17 opening price or the completed 9:17 candle.
2. Build secure backend for Angel One SmartAPI, credentials kept server-side.
3. Add compliant market data/order workflow and test in paper mode.
4. Add audit logs, daily trade lock, SL/target monitoring and failure handling.
