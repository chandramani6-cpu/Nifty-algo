const spot=document.getElementById('spot');
const green=document.getElementById('green'), red=document.getElementById('red');
const signal=document.getElementById('signal'), entry=document.getElementById('entry');
const sl=document.getElementById('sl'), target=document.getElementById('target');
const notice=document.getElementById('notice');
let candle='green';
function update(){
  const p=Number(spot.value);
  const valid=Number.isFinite(p)&&p>0;
  entry.textContent=valid?p.toFixed(2):'—';
  sl.textContent=valid?(p+(candle==='green'?-20:20)).toFixed(2):'—';
  target.textContent=valid?(p+(candle==='green'?40:-40)).toFixed(2):'—';
  signal.textContent=candle==='green'?'BUY CE':'BUY PE';
  signal.className=candle==='green'?'signal':'signal red';
}
green.addEventListener('click',()=>{candle='green';green.classList.add('active','green');red.classList.remove('active','red');notice.textContent='Green candle selected.';update()});
red.addEventListener('click',()=>{candle='red';red.classList.add('active','red');green.classList.remove('active','green');notice.textContent='Red candle selected.';update()});
spot.addEventListener('input',update);
document.getElementById('generate').addEventListener('click',()=>{
  if(!(Number(spot.value)>0)){notice.textContent='कृपया सही NIFTY price डालें।';return}
  notice.textContent=`Demo signal: ${candle==='green'?'BUY ATM CE':'BUY ATM PE'} · Entry ${Number(spot.value).toFixed(2)} · कोई order नहीं भेजा गया।`;
});
if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js'));
update();